from django.shortcuts import render
import requests
import sys
from subprocess import run,PIPE
def button(request):
	return render(request,'home.html')
def external(request):
	inp=request.POST.get('param')#add path of python file in that position
	out=run([sys.executable,'C://Users//suBITCHaaaaa//time.py',inp],shell=False,stdout=)
	print(out)
	return render(request,'home.html',{'data1':out.stdout})
 