import pandas as pd
import re
import nltk
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import glob
import os
#all import statements

from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer, TfidfTransformer
#preprocessing requirements

from sklearn.model_selection import train_test_split
from sklearn.externals import joblib
from sklearn.pipeline import Pipeline
#training and pipeline works

from sklearn.model_selection import cross_val_score
from sklearn.svm import SVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
#functions

from matplotlib.ticker import FuncFormatter
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import GridSearchCV
#confusion matirx

sns.set(color_codes = True)
%matplotlib inline

df = pd.read_csv("editeddataset.csv")
#df.head()#database connected successful

from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator
# Extract only text of reviews
heading_1 = df[df["Score"]=="positive"]["Summary"] 
collapsed_heading_1 = heading_1.str.cat(sep=' ')
heading_2 = df[df["Score"]=="negative"]["Summary"] 
collapsed_heading_2 = heading_2.str.cat(sep=' ')
heading_3 = df[df["Score"]=="neutral"]["Summary"] 
collapsed_heading_3 = heading_3.str.cat(sep=' ')
#print(heading_3)
heading=collapsed_heading_1+collapsed_heading_2+collapsed_heading_1

df=pd.DataFrame(df)
#print(dataset)
nltk.download('stopwords')

corpus=[]

for i in range(0,1500):
    text=re.sub('[^a-zA-z]',' ',df['Summary'][i])
    text=text.lower()
    text=text.split()
    ps=PorterStemmer()
    text=''.join(text)
    corpus.append(text)
    

    #creating BOW
cv=CountVectorizer(max_features=1500)
#print(corpus)
X=cv.fit_transform(corpus).toarray()
#print(X.shape)
y=df.iloc[:,6].values
#print(y.shape)


#splitting data set into training and test data set

from sklearn.model_selection import train_test_split

X_train,X_test,y_train,y_test= train_test_split(X,y,test_size=0.10,random_state=1)
#print(X_train)
#print(X_test)
#print(y_train)
#print(y_test)

#fitting naive bayes into training set


classifier= RandomForestClassifier();
model=classifier.fit(X_train,y_train)
y_pred=classifier.predict(X_test)
#print(y_pred)


print("Accuracy ofSVM is {}".format(model.score(X_test,y_test)))