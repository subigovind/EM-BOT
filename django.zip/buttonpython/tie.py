import sys
import datetime

time=datetime.datetime.now()

output="hi %s time is %s" % (sys.agrv[1],time)

print(output)
